import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Menu, X, ArrowUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import SiteFooter from "@/components/layout/SiteFooter";
import PageSEO from "@/components/shared/PageSEO";

const NAV_ITEMS = [
  { label: "Home", page: "Home" },
  { label: "The Journey", page: "TheJourney" },
  { label: "L.U.V. Drops®", page: "LuvDrops" },
  { label: "How Nel Helps", page: "HowNelHelps" },
  { label: "Media", page: "Media" },
  { label: "Book Nel", page: "BookNel" },
  { label: "Contact", page: "Contact" },
];

export default function Layout({ children, currentPageName }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
      setShowScrollTop(window.scrollY > 600);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [currentPageName]);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "var(--cream)" }}>
      <PageSEO pageName={currentPageName} />
      {/* Navigation */}
      <header
        className={`fixed top-0 left-0 right-0 z-20 transition-all duration-300 ${
          scrolled
            ? "bg-white/90 backdrop-blur-md shadow-sm"
            : "bg-transparent"
        }`}
      >
        <nav className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link
              to={createPageUrl("Home")}
              className="flex items-center gap-3 group"
            >
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6957c856c67dda2bc81864b6/96381b237_image.png"
                alt="Nel Duo logo"
                width={42}
                height={42}
                className="rounded-full"
              />
              <span
                className="font-serif text-xl font-semibold tracking-tight"
                style={{ color: "var(--navy)", fontFamily: "'Playfair Display', serif" }}
              >
                <span className="flex flex-col leading-tight">
                <span style={{ fontFamily: "'Playfair Display', serif", color: "var(--navy)" }} className="text-lg font-semibold tracking-tight">Nel Duo</span>
                <span className="text-[10px] font-semibold uppercase tracking-[0.18em]" style={{ color: "var(--blue-accent)" }}>L.U.V. Drops®</span>
              </span>
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-5 xl:gap-7">
              {NAV_ITEMS.map((item) => (
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  className={`text-sm font-medium transition-colors duration-200 whitespace-nowrap ${
                    currentPageName === item.page
                      ? "text-[var(--blue-accent)]"
                      : "text-[var(--text-secondary)] hover:text-[var(--navy)]"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
              <Link
                to={createPageUrl("BookNel")}
                className="text-sm font-semibold px-5 py-2.5 rounded-full transition-all duration-200 hover:opacity-90 whitespace-nowrap flex-shrink-0"
                style={{ backgroundColor: "#b89b5e", color: "#0f1e2e" }}
              >
                Book a Conversation
              </Link>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 -mr-2 cursor-pointer"
              aria-label={mobileOpen ? "Close menu" : "Open menu"}
            >
              {mobileOpen ? (
                <X className="w-6 h-6" style={{ color: "var(--navy)" }} />
              ) : (
                <Menu className="w-6 h-6" style={{ color: "var(--navy)" }} />
              )}
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="lg:hidden bg-white/95 backdrop-blur-md border-t border-gray-100 overflow-hidden"
            >
              <div className="px-6 py-6 flex flex-col gap-4">
                {NAV_ITEMS.map((item) => (
                  <Link
                    key={item.page}
                    to={createPageUrl(item.page)}
                    className={`text-base font-medium py-2 transition-colors duration-200 ${
                      currentPageName === item.page
                        ? "text-[var(--blue-accent)]"
                        : "text-[var(--text-secondary)]"
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                <Link
                  to={createPageUrl("BookNel")}
                  className="mt-2 text-center text-sm font-medium px-5 py-3 rounded-full"
                  style={{ backgroundColor: "#b89b5e", color: "#0f1e2e" }}
                >
                  Book a Conversation
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Page content */}
      <main className="flex-1 pt-16 lg:pt-20">{children}</main>

      {/* Footer */}
      <SiteFooter />

      {/* Scroll to top */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="fixed bottom-6 right-6 z-30 w-11 h-11 rounded-full flex items-center justify-center shadow-lg cursor-pointer transition-opacity duration-200 hover:opacity-80"
            style={{ backgroundColor: "var(--navy)", color: "white" }}
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}